# Jawahar Portfolio — GitHub Pages

This is the first coded version of the portfolio based on the content currently visible on the Wix portfolio.

## Folder structure

- index.html
- style.css
- script.js
- images/
- assets/

## Add your images

Replace the placeholder files referenced in `index.html`:

- images/graphic-01.jpg
- images/sunrise-mobile.jpg
- images/sunrise-verification.jpg
- images/jomfresh.jpg
- images/ott.jpg
- images/preludesys.jpg
- images/amazon.jpg
- images/motion.jpg

Keep the filenames or edit the `<img src="">` paths.

Put your CV at:

`assets/Jawahar-CV.pdf`

## Run locally

Open `index.html` in a browser.

For easier editing, install VS Code and use the Live Server extension.

## Publish on GitHub Pages

1. Create a GitHub account.
2. Create a public repository named exactly:
   `YOURUSERNAME.github.io`
3. Upload all files and folders from this project.
4. In Settings → Pages, choose the publishing source recommended by GitHub.
5. Your site will be available at:
   `https://YOURUSERNAME.github.io`

GitHub Pages supports static HTML/CSS/JavaScript sites and does not require separate hosting.

## Important

The Wix site contains the original portfolio images. This code intentionally references local `images/` files so you own/control the site's assets instead of depending on Wix's image CDN.
